//step 1: npm init -y

//step 2: npm i -g nodemon 

// step 3: npm i mysql

//step 4: npm i express

// step 5: package.json-> scripts-> "start": "nodemon index.js"

//step 6: create index.js 


// to run application: npm start