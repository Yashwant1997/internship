// npm create vite@latest project_name
// cd project_name
// npm install
// npm run dev

// to change port: vite.config.js
                  server: {
                    port:3000
                  }
// adding bootsrap in react using npm: npm install bootstrap --save 
                            main.jsx :import "bootstrap/dist/css/bootstrap.min.css";

// configure routing: npm install react-router-dom --save
            App.jsx : import  {BrowserRouter, Routes, Route} from 'react-router-dom'

// import axios to  make http requests: npm install axios --save
                   
         